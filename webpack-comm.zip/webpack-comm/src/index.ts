// 导出插件
export { default as Lucky } from '@/packages/lucky'