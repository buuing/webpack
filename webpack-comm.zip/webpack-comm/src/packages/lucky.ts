
export default class Lucky {
  constructor () {
    console.log(234)
  }
  test () {
    alert('ok')
  }
}
